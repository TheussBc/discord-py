import sqlite3
from discord.ext import commands
from emojis import EMOJI_CHECK, EMOJI_X

class DatabaseCommand(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="database")
    async def database(self, ctx):
        if ctx.author.id == 1132819646651842620:
            conn = sqlite3.connect("database.db")
            cursor = conn.cursor()
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS daily (
            ID TEXT PRIMARY KEY,
            Status INTEGER NOT NULL)''')
            conn.commit()
            conn.close()
            await ctx.send(f"{EMOJI_CHECK} DB criada com sucesso.")
        else:
            await ctx.send(f"{EMOJI_X} Você não tem permissão para executar este comando.")

async def setup(bot):
    await bot.add_cog(DatabaseCommand(bot))
